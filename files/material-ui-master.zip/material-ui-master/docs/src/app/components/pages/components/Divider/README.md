## Divider

[Dividers](https://www.google.com/design/spec/components/dividers.html) group and separate content within lists and page layouts. The divider is a thin rule, lightweight yet sufficient to distinguish content visually and spatially.

### Examples
