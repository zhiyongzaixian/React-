## Toolbar

[Toolbars](https://www.google.com/design/spec/layout/structure.html#structure-toolbars) are collections of components stacked horizontally against each other.
Toolbars provide greater versatility than AppBars which are a subset of toolbars.
The following toolbar components can help organize your layout.

### Examples
