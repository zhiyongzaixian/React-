## Raised Button
This [button](https://www.google.com/design/spec/components/buttons.html#buttons-flat-raised-buttons)
is used to add dimension to mostly flat layouts and emphasizes important functions on your page.

### Examples
