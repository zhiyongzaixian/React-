## Popover

A `Popover` can be used as an alternative to a [Drop Down Menu](/#/components/dropdown-menu)
that can contain elements inside. In our examples we are using a [Menu](/#/components/menu),
but any suitable combination of components can be used.

### Examples
