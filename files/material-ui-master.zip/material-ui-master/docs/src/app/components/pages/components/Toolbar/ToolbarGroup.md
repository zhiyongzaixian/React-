### ToolbarGroup Properties

`ToolbarGroup` contains a collection of components for you. 
It is recommended that all components in a `Toolbar` are contained within a `ToolbarGroup`.
