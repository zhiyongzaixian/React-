## Circular Progress
[Circular Progress](https://www.google.com/design/spec/components/progress-activity.html#progress-activity-types-of-indicators)
will rotate to show the progress of a task or that there is a wait for a task to complete. 

### Examples
