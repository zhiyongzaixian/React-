## Badge

This component generates a small badge to the top-right of its child(ren).

### Examples
