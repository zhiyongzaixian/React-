## Menu
[Menus](https://www.google.com/design/spec/components/menus.html) allow you to
take an action by selecting from a list revealed upon opening a temporary,
new sheet of material.

A `Menu` is typically used in a [Popover](/#/components/popover).

### Examples
