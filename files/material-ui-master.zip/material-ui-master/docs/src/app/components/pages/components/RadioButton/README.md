## Radio Button

[Radio buttons](https://www.google.com/design/spec/components/selection-controls.html#selection-controls-radio-button)
are switches used for selection from multiple options.

### Examples
