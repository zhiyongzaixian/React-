### ToolbarTitle Properties

A simple text that is displayed in the `Toolbar`.
