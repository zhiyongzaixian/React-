## Text Field

[Text fields](https://www.google.com/design/spec/components/text-fields.html)
allow users to input text.

### Examples
