## Drawer

The [Drawer](https://www.google.com/design/spec/patterns/navigation-drawer.html) slides in from the side.
It is a common pattern found in Google apps and follows the keylines and metrics for lists.

There are no examples for uncontrolled mode because an uncontrolled `Drawer` can only be opened with a swipe.
The doc site has an uncontrolled `Drawer`. Swipe from the left on a touch device to see it.

### Examples
