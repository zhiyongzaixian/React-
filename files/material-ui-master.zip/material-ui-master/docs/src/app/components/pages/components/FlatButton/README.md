## Flat Button

[Flat Buttons](https://www.google.com/design/spec/components/buttons.html#buttons-flat-raised-buttons)
are used for general functions and reduce the amount of layering on the screen,
making it more readable.

### Examples
