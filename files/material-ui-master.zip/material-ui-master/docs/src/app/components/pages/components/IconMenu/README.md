## Icon Menu

[Icon Menus](https://www.google.com/design/spec/components/menus.html#menus-usage)
are menus that open from icons. They can give options related to the icon and use
a minimal space.

### Examples
