## Bottom Navigation

The [bottom navigation](https://www.google.com/design/spec/components/bottom-navigation.html#bottom-navigation-behavior) is a special kind of toolbar that’s used for navigation.

### Examples
