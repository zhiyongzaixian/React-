### ToolbarSeparator Properties

A vertical bar used to separate groups of components. 
It is used to easily organize components within a `Toolbar`.
