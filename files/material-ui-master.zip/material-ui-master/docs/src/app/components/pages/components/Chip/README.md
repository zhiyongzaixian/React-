## Chip

[Chips](https://www.google.com/design/spec/components/chips.html) 
represent complex entities in small blocks, such as a contact.

While included here as a standalone component, the most common use will
be in some form of input, so some of the behaviour demonstrated is not
shown in context.

### Examples
