## Auto Complete
The [auto-complete](https://www.google.com/design/spec/components/text-fields.html#text-fields-auto-complete-text-field)
is an extension of a regular text-field that will auto-complete the input dynamically. It can take different auto-complete filters and
uses a menu to display suggestions.

### Examples
