## List
[Lists](https://www.google.com/design/spec/components/lists.html#) are used to present
multiple items vertically as a single continuous element. They can be configured for
many uses such as a contacts list, nested lists, etc.

### Examples
