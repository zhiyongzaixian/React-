## Paper
A [Paper](https://www.google.com/design/spec/layout/principles.html#principles-how-paper-works)
element is a basic container that can give depth to the page.

### Examples
