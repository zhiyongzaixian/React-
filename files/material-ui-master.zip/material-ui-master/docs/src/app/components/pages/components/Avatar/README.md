## Avatar

Avatars can be used to represent people or object.

### Examples
