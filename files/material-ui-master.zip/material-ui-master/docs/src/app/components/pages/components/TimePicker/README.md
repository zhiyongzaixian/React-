## Time Picker

A [time picker](https://www.google.com/design/spec/components/pickers.html#pickers-time-pickers)
is used to input a time by displaying an interface the user can interact with.

### Examples
