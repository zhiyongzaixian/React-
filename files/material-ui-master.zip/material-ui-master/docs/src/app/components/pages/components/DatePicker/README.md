## Date Picker
[Date Pickers](https://www.google.com/design/spec/components/pickers.html#pickers-date-pickers) are used to select a single date for an input. 
### Examples
