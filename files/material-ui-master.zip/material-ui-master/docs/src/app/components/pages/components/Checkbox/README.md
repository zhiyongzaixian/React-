## Checkbox

A [checkbox](https://www.google.com/design/spec/components/selection-controls.html#selection-controls-checkbox)
is used to verify which options you want selected from a group.

### Examples
