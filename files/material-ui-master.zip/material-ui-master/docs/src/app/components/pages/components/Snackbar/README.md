## Snackbar

[Snackbars](https://www.google.com/design/spec/components/snackbars-toasts.html) provide lightweight feedback about an operation by showing a brief message at the bottom of the screen. Snackbars can contain an action.
