## Floating Action Button

The [Floating Action Button](https://www.google.com/design/spec/components/buttons-floating-action-button.html)
is used for frequently used functions.

### Examples
