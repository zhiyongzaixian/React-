## Toggle

A [toggle switch](https://www.google.com/design/spec/components/selection-controls.html#selection-controls-switch)
is used as an on/off control.

### Examples
