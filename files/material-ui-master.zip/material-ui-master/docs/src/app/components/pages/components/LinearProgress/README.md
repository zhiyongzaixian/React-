## Linear Progress
[Linear Progress](https://www.google.com/design/spec/components/progress-activity.html#progress-activity-types-of-indicators)
bars fill from 0% to 100% to show the progress of a task. It also will animate to
show there is a task waiting to be done.

### Examples
