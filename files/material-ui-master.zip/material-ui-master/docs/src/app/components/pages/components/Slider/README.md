## Slider
A [slider](https://www.google.com/design/spec/components/sliders.html)
is an interface for users to input a value in a range. Sliders can be continuous
or discrete and can be enabled or disabled.
### Examples
