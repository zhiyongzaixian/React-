## App Bar

The [app bar](https://www.google.com/design/spec/layout/structure.html#structure-app-bar), formerly known as the action bar in Android,
is a special kind of toolbar that’s used for branding, navigation, search, and actions.

### Examples
