## Note

The `event.preventDefault();` in the examples above is to prevent an effect called [ghost click](http://ariatemplates.com/blog/2014/05/ghost-clicks-in-mobile-browsers/) that happens with touch-devices. It is recommended that you add that call whenever you handle a `TouchTap` event associated with closing/opening `Popover`.
