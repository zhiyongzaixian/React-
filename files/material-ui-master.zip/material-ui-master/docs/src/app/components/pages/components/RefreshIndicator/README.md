## Refresh Indicator
The [refresh indicator](https://www.google.com/design/spec/components/progress-activity.html#)
is used when showing an item is loading. It is kept hidden from the interface until it's
status prop is changed to `loading` or `ready`.

### Examples
