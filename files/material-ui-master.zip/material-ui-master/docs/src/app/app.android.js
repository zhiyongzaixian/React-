import {
  AppRegistry,
} from 'react-native';

import App from './app.native';

AppRegistry.registerComponent('App', () => App);
