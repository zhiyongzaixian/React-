<!-- Have a QUESTION? Please ask in [StackOverflow or gitter](http://tr.im/77pVj before opening an issue.

If you are having an issue with click events, please re-read the [README](http://tr.im/410Fg) (you did read the README, right? :-) ).

If you think you have found a _new_ issue that hasn't already been reported or fixed in HEAD, please complete the template below.

For feature requests, please delete the template below and use this one instead:

### Description
### Images & references

-->

### Problem description

### Link to minimally-working code that reproduces the issue

<!-- You may provide a repository or use our template-ready webpackbin http://www.webpackbin.com/EyKSRJ7UM -->

### Versions

- Material-UI:
- React:
- Browser:
