export default from './FlatButton';
