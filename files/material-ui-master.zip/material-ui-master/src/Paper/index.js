export default from './Paper';
