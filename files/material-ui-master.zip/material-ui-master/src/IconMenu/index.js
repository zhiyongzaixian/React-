export IconMenu from './IconMenu';
export MenuItem from '../MenuItem/MenuItem';

export default from './IconMenu';
