export default from './FontIcon';
