export default from './SvgIcon';
