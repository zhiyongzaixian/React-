export default from './Slider';
