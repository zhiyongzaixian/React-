export Tab from './Tab';
export Tabs from './Tabs';

export default from './Tabs';
